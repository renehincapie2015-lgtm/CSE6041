package eIlumage;

/**
 * Modela el Inventario de Productos
 */
public abstract class Inventario {

    protected int count = 0;

    /**
     *
     * @param producto
     * @param cantidad
     */
    public abstract void addStock(Producto producto, int cantidad);

    /**
     *
     * @param nombre
     */
    public abstract void getStock(String nombre);

    /**
     *
     * @param cantidad
     */
    public abstract void upStock(int cantidad);

    /**
     *
     * @param cantidad
     */
    public abstract void downStock(int cantidad);

    public abstract int getCantidad();

}
