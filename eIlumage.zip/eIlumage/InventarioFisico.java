package eIlumage;

public class InventarioFisico extends Inventario {

    private StockFisico[] stocks;
    private StockFisico stock;

    /**
     *
     * @param producto
     * @param cantidad
     */
    @Override
    public void addStock(Producto producto, int cantidad) {
        if (producto instanceof ProductoFisico) {
            if (count == 0) {
                stocks = new StockFisico[10];
            }
            stock = new StockFisico();
            stock.setProducto(producto);
            stock.setCantidad(cantidad);
            stocks[count] = stock;
            count++;
        }
    }

    /**
     *
     * @param nombre
     */
    @Override
    public void getStock(String nombre) {
        int pos = 0;
        boolean encontrado = false;

        while (!encontrado && pos < this.count) {
            if (stocks[pos].getProducto().getNombre().equals(nombre)) {
                this.stock = stocks[pos];
                encontrado = true;
                break;
            }
            pos++;
        }
        if (pos == this.count) {
            this.stock = null;
            System.out.println("Stock del Producto Fisico " + nombre + " no existe o no pertenece a este Inventario");
        }
    }

    /**
     *
     * @param cantidad
     */
    @Override
    public void upStock(int cantidad) {
        if (stock != null) {
            stock.setCantidad(stock.getCantidad() + cantidad);
            System.out.println(stock.getProducto().getNombre() + " aumentó en " + cantidad);
        } else {
            System.out.println("No ha consultado un Stock");
        }
    }

    /**
     *
     * @param cantidad
     */
    @Override
    public void downStock(int cantidad) {
        if (stock != null) {
            stock.setCantidad(stock.getCantidad() - cantidad);
            System.out.println(stock.getProducto().getNombre() + " disminuyó en " + cantidad);
        } else {
            System.out.println("No ha consultado un Stock");
        }
    }

    @Override
    public int getCantidad() {
        if (stock != null) {
            return stock.getCantidad();
        } else {
            System.out.println("No ha consultado un Stock");
            return 0;
        }
    }

}
