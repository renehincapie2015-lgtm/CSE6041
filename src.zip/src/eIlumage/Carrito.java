package eIlumage;

/**
 * Modela el carro de compras
 */
public class Carrito {

    private int codigo;
    private Articulo[] articulos;
    private int count = 0;
    private float total = Float.parseFloat("0");
    private static int consecutivo = 0;

    public Carrito() {
        this.codigo = ++Carrito.consecutivo;
        this.articulos = new Articulo[50];
    }

    /**
     *
     * @param articulo
     */
    public void addArticulo(Articulo articulo) {
        articulos[this.count] = articulo;
        this.total += articulos[this.count].getSubTotal();
        this.count++;
    }

    /**
     *
     * @param producto
     * @param cantidad
     */
    public void addArticulo(Producto producto, int cantidad) {
        if (cantidad <= 0) {
            System.out.println("La cantidad debe ser positiva");
        } else {
            articulos[count] = new Articulo(new Stock(producto, cantidad));
            this.total += articulos[count].getSubTotal();
            this.count++;
        }
    }

    /**
     *
     * @param nombre
     * @param valor
     * @param peso
     * @param dimensiones
     * @param color
     * @param cantidad
     */
    public void addArticulo(String nombre, float valor, float peso, String dimensiones, String color, int cantidad) {
        String mensaje = "";

        if (nombre == null || nombre.trim().isEmpty()) {
            mensaje += "El nombre viene vacío. ";
        }
        if (valor <= 0.0f) {
            mensaje += "El valor debe ser positivo. ";
        }
        if (peso <= 0.0f) {
            mensaje += "El peso debe ser positivo. ";
        }
        if (dimensiones == null || dimensiones.trim().isEmpty()) {
            mensaje += "Las dimensiones vienen vacías. ";
        }
        if (color == null || color.trim().isEmpty()) {
            mensaje += "El color viene vacío. ";
        }
        if (cantidad <= 0) {
            mensaje += "La cantidad debe ser positiva. ";
        }
        if (mensaje == null || mensaje.trim().isEmpty()) {
            articulos[count] = new Articulo(new Stock(new ProductoFisico(nombre.trim(), valor, peso, dimensiones.trim(), color.trim()), cantidad));
            this.total += articulos[count].getSubTotal();
            this.count++;
        } else {
            System.out.println(mensaje);
        }
    }

    /**
     *
     * @param nombre
     * @param valor
     * @param formatoArchivo
     * @param tamano
     * @param codec
     * @param cantidad
     */
    public void addArticulo(String nombre, float valor, String formatoArchivo, String tamano, String codec, int cantidad) {
        String mensaje = "";

        if (nombre == null || nombre.trim().isEmpty()) {
            mensaje += "El nombre viene vacío. ";
        }
        if (valor <= 0.0f) {
            mensaje += "El valor debe ser positivo. ";
        }
        if (formatoArchivo == null || formatoArchivo.trim().isEmpty()) {
            mensaje += "El formato de archivo viene vacío. ";
        }
        if (tamano == null || tamano.trim().isEmpty()) {
            mensaje += "El tamano viene vacío. ";
        }
        if (codec == null || codec.trim().isEmpty()) {
            mensaje += "El codec viene vacío. ";
        }
        if (cantidad <= 0) {
            mensaje += "La cantidad debe ser positiva. ";
        }
        if (mensaje == null || mensaje.trim().isEmpty()) {
            articulos[count] = new Articulo(new Stock(new ProductoDigital(nombre, valor, formatoArchivo, tamano, codec), cantidad));
            this.total += articulos[count].getSubTotal();
            this.count++;
        } else {
            System.out.println(mensaje);
        }
    }

    /**
     *
     * @param nombre
     * @param cantidad
     */
    public void setCantidadArticulo(String nombre, int cantidad) {
        int pos = 0;
        float valor;
        boolean encontrado = false;
        Stock stock;
        Producto producto;
        String mensaje = "";

        if (nombre == null || nombre.trim().isEmpty()) {
            mensaje += "El nombre viene vacío. ";
        }
        if (cantidad <= 0) {
            mensaje += "La cantidad debe ser positiva. ";
        }

        if (mensaje == null || mensaje.trim().isEmpty()) {
            while (!encontrado && pos < count) {
                stock = articulos[pos].getStock();
                producto = stock.getProducto();
                if (producto.getNombre().equals(nombre)) {
                    valor = Float.parseFloat(producto.getCaracteristica("Valor").getValor());
                    this.total -= valor * stock.getCantidad();
                    stock.setCantidad(cantidad);
                    this.total += valor * cantidad;
                    encontrado = true;
                    break;
                }
                pos++;
            }
            if (pos == count) {
                System.out.println("Artículo llamado " + nombre + " no existe o no pertenece a este Carrito");
            }
        } else {
            System.out.println(mensaje);
        }
    }

    /**
     *
     * @param nombre
     */
    public void deleteArticulo(String nombre) {
        int pos = 0;
        boolean encontrado = false;

        if (nombre == null || nombre.trim().isEmpty()) {
            System.out.println("El nombre viene vacío. ");
        } else {
            while (!encontrado && pos < count) {
                if (articulos[pos].getStock().getProducto().getNombre().equals(nombre)) {
                    articulos[pos] = null;
                    encontrado = true;
                    break;
                }
                pos++;
            }
            if (pos == count) {
                System.out.println("Artículo llamado " + nombre + " no existe o no pertenece a este Carrito");
            }
        }
    }

    public float getTotal() {
        return this.total;
    }

    public void updateInventario(Inventario inv) {
        Stock stock;

        for (int i = 0; i < this.count; i++) {
            stock = articulos[i].getStock();
            inv.getStock(stock.getProducto().getNombre());
            inv.downStock(stock.getCantidad());
        }
    }

    public String getPedido() {
        Stock stock;
        String texto = "ILUMAGE le informa que ya fue entregada su compra, que consiste de\n";
        texto += "Valor\tCant\tSubTot\tNombre\n"
                + "------- ------- ------- ------\n";

        for (int i = 0; i < this.count; i++) {
            stock = articulos[i].getStock();
            texto += stock.getProducto().getCaracteristica("Valor").getValor() + "\t"
                    + stock.getCantidad() + "\t"
                    + Float.toString(articulos[i].getSubTotal()) + "\t"
                    + stock.getProducto().getFullNombre() + "\n";
        }
        texto += "------- ------- ------- ------\n"
                + "TOTAL           " + Float.toString(this.total);
        return texto;
    }

    public void dumpCarrito() {
        for (int i = 0; i < this.count; i++) {
            articulos[i] = null;
        }
    }

}
